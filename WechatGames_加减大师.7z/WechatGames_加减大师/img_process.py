#coding=utf-8

import os
import time
from PIL import Image
from pymouse import PyMouse
import cv2
import numpy as np 

#此模块的输入为 Windows截图 数据类型是？？

def binarize(img):
    '''
    functions:
    将截取的图片进行二值化
    '''
    #将PIL.Image.Image转化为OpenCV的格式 并转为灰度化图像
    img = cv2.cvtColor(np.asarray(img),cv2.COLOR_RGB2BGR)

    #设定阈值 进行二值化
    threshold = 200
    param = cv2.THRESH_BINARY

    ret,processed = cv2.threshold(img,threshold,255,param)

    #print(type(processed))
    #cv2.imshow("win100",img)
    #cv2.imshow("win001",processed)
    #cv2.waitKey(0)
    return processed#返回类型为numpy.ndarray的二值化图像

def S_cut(img):#
    num = 0
    list1 = []
    print(img.ndim)
    print(img.shape)
    for i in range(img.shape[0]):
        if img[i,...].any() != 0:
            if num == 0:
                list1.append(i)
        num+=1
            #print(i) 
        if num >= 1:
            if img[i,...].all() == 0:
                print(i)
                break
            
    '''
    水平切割 固定切成上下两块 返回两张图片 类型为numpy.ndarray
    '''




def Z_cut(img):#函数将两张图片 切割成单字符并按次序把存在 cut_temp 里
    '''
    输入单张 单行数字，运算符的图片
    返回 若干张切割好的有次序大小一致的单字符图片
    '''




def main():
    img = Image.open("001.png")
    img_uncut = binarize(img)
    S_cut(img_uncut)
if __name__ == "__main__":
    main()