import os
import sys
import time
import traceback
import numpy as np
from pymouse import PyMouse
#from imgtools import *
from PIL import Image
from config import location_on_pc as loc,threshold
import cv2
from img_process import binarize,S_cut,Z_cut
#from MatchTemplate_Test_Nomalization import Chars_recognition


def get_screenshot():
    if sys.platform == 'win32':
        from PIL import ImageGrab
        scr = ImageGrab.grab([loc['left_top_x'], loc['left_top_y'], loc['right_buttom_x'], loc['right_buttom_y']])
        return scr
    elif sys.platform == 'linux':
        cmd = 'import -window root -crop {0}x{1}+{2}+{3} screenshot.png'
        cmd = cmd.format(loc['right_buttom_x'] - loc['left_top_x'], loc['right_buttom_y'] - loc['left_top_y'],
                         loc['left_top_x'], loc['left_top_y'])
        os.system(cmd)
        scr = Image.open('screenshot.png')
        return scr
    else:
        print('Unsupported platform: ', sys.platform)
        sys.exit()




        

def Chars_recognition(cut_char_filename):
    '''
    输入 单张待识别的字符图片 
    与标准模板字符进行一一匹配，得到字符对应的值
    '''
    list1 = [0,1,2,3,4,5,6,7,8,9,"-","+","="]
    d = {}
    

    for i in list1:
        filename = "Template/source/Themaplate/"+str(i)+".png"
        img = cv2.imread(cut_char_filename,1)
        gray = cv2.imread(cut_char_filename,0)


        img_template = cv2.imread(filename,0)

        #模板字符图片的宽 高
        w , h = img_template.shape[::-1]
        #print(w,h)

        #代识别字符的信息
        weight , height = gray.shape[::-1]

        ##2.将模板resize成待识别字符的大小

        img_template_resized = cv2.resize(img_template,(weight,height))
        #模板匹配的操作
        res = cv2.matchTemplate(gray,img_template_resized,cv2.TM_SQDIFF_NORMED)

        #得到最大和最小值的位置
        min_val,max_val,min_loc,max_loc = cv2.minMaxLoc(res)

        #print(min_val)
        #print(max_val)
        d[str(i)] = max_val

        #top_left = min_loc#左上角的位置
        #bottom_right = (top_left[0]+w,top_left[1]+h)#右下角的位置
    #print(d)
    list2 = list(d.items())
    #print(list2)
    list2.sort(key=lambda x:x[1])
    #print(list2)

    print("{}字符识别结果为：{}".format(cut_char_filename[9:],list2[0][0]))
        #原图上做标注！
        #cv2.rectangle(img,top_left,bottom_right,(0,0,255),2)

        #cv2.imshow("win1_source",img_template)
        #cv2.imshow("win2_match",img)
        #cv2.waitKey(0)

    

def strings_process():
    pass


def main():
    region = get_screenshot()
    #print(type(region))
    #Image._show(region)

    bin_img = binarize(region)

    #S_cut()#

    #Z_cut()#

    for maindir,subdir,temp_cut_char_name in os.walk("cut_temp"):
        #print(temp_cut_char_name)
        for i in temp_cut_char_name:
            #print(i)
        #Chars_recognition("Template/source/demo_match_recogitiom/tests/test04.png")
            Chars_recognition("cut_temp/"+i)
    #cv2.imshow("windosw111",bin_img)
    #cv2.waitKey(0)
if __name__ == "__main__":
    t1 = time.time()
    main()
    t2 = time.time()

    print(t2-t1)
    


    

    #[img_up ,img_down] = horizontal_cut(bin_img)
    #Image.SAVE("temp_source",region)
    
    #cv2.imwrite("temp_source.png",region)
