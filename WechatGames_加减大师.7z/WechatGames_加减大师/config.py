# 算式区域在电脑屏幕上的坐标
location_on_pc = {'left_top_x': 68, 'left_top_y': 259, 'right_buttom_x': 294, 'right_buttom_y': 394, 'click_true_x': 103, 'click_true_y': 517, 'click_false_x': 250, 'click_false_y': 527}
#location_on_pc = {'left_top_x': 100, 'left_top_y': 300, 'right_buttom_x': 380, 'right_buttom_y': 480, 'click_true_x': 150, 'click_true_y': 650, 'click_false_x': 350, 'click_false_y': 650}
# 是否显示各项用时
# debug = False

# 二值化的阈值
threshold = 230